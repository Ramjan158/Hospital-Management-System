<html>
<head>
<link rel="shortcut icon" type="image/x-icon" href="images/favicon.png" />
</head>
</html>